package com.youth.market.admin.dto;

public class AdminBan {

}
