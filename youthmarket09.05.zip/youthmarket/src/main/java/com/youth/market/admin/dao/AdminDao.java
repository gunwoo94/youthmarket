package com.youth.market.admin.dao;

import com.youth.market.admin.dto.Admin;

public interface AdminDao {

	Admin loginChk(String adminId);

	
}
