package com.youth.market.sell.dto;

/*
import lombok.AllArgsConstructor;
import lombok.Builder;*/
import lombok.Data;

/*import lombok.NoArgsConstructor;

*/
@Data
public class Category {
	
	private int categoryNo;
	private String categoryName;

}
