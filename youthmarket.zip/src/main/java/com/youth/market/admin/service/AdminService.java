package com.youth.market.admin.service;

import com.youth.market.admin.dto.Admin;

public interface AdminService {

	Admin loginChk(String adminId);

}
